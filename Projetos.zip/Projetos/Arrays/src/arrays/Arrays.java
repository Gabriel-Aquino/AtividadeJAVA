
package arrays;

public class Arrays {
    public static void main(String[] args) {
        
        Array1 a1 = new Array1();
        Array2 a2 = new Array2();
        
        a1.main(args);
        a2.main(args);
    }
    
}
