
package arrays;
public class Array2 {

    public static void main(String[] args){
        int[] vet = new int[11];
        
        for (int i = 0; i < 11; ++i){
         
            vet[i] += 3;
            
            System.out.println("Valores: "+vet[i]);
        }
    }
}
