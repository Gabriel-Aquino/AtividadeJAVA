
package animais;

public class Animais {

    public static void main(String[] args) {
        
    }
    
}
