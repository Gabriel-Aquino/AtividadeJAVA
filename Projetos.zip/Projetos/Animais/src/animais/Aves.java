
package animais;

public abstract class Aves {
    public abstract void Voar();
    public abstract void Comer();
    public abstract void Reproduzir();
    public abstract void Comunicar();
    
    private Comida c = new Comida();
    private Pelagem p = new Pelagem();

    public Comida getC() {
        return c;
    }

    public void setC(Comida c) {
        this.c = c;
    }

    public Pelagem getP() {
        return p;
    }

    public void setP(Pelagem p) {
        this.p = p;
    }

    @Override
    public String toString() {
        return this.p.toString()+"\n"+this.c.toString();
    }
    
}

class Pombo extends Aves{
    String cor;
    float tamanho;
    
    
    @Override
    public void Voar() {
        System.out.println("Pombos nao voam dos carros para salvar suas vidas.");
    }

    @Override
    public void Comer() {
        System.out.println("Pombos Alimentam-se de pedras"+this.getC());
    }

    @Override
    public void Reproduzir() {
        System.out.println("Só o que tem é pombo, eles reproduzem muito");
    }

    @Override
    public void Comunicar() {
        System.out.println("PRU!");
    }
    
}

class Gaviao extends Aves{

    @Override
    public void Voar() {
        System.out.println("Voam Para Caçar.");
    }

    @Override
    public void Comer() {
        System.out.println("Alimentam-se de outras aves ou répteis"+this.getC());
    }

    @Override
    public void Reproduzir() {
        System.out.println("Demoram Reproduzir, e tem poucas crias");
    }

    @Override
    public void Comunicar() {
        System.out.println("Apenas com o parceiro ou com as crias");
    }
    
}