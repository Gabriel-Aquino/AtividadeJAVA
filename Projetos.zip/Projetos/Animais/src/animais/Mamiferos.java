
package animais;

public interface Mamiferos {
    public abstract void Andar();
    public abstract void Correr();
    public abstract void Comer();
    public abstract void Reproduzir();
}


class Humanos implements Mamiferos{
    float altura;
    String cor;
    int idade;
    float peso;
    
    private Comida c1 = new Comida();
    private Pelagem p1 = new Pelagem();

    public Comida getC() {
        return c1;
    }

    public void setC(Comida c) {
        this.c1 = c;
    }

    public Pelagem getP() {
        return p1;
    }

    public void setP(Pelagem p) {
        this.p1 = p;
    }

    @Override
    public String toString() {
        return this.p1.toString()+"\n"+this.c1.toString();
    }
    
    
    
    @Override
    public void Andar() {
        System.out.println("Humanos pegam Sol, a cor altera.");
    }

    @Override
    public void Correr() {
        System.out.println("Humanos Correm para fazer exercicios ou por rotina.");
    }

    @Override
    public void Comer() {
        System.out.println("Humanos alimentam-se para sobreviver.");
    }

    @Override
    public void Reproduzir() {
        System.out.println("Humanos se casam e se reproduzem.");
    }

}
class Cachorros implements Mamiferos{
    String cor;
    float peso;
    String raça;
    
    private Comida c2 = new Comida();
    private Pelagem p2 = new Pelagem();

    public Comida getC() {
        return c2;
    }

    public void setC(Comida c) {
        this.c2 = c;
    }

    public Pelagem getP() {
        return p2;
    }

    public void setP(Pelagem p) {
        this.p2 = p;
    }

    @Override
    public String toString() {
        return this.p2.toString()+"\n"+this.c2.toString();
    }
    
    @Override
    public void Andar() {
        System.out.println("Cachorros andam para vigiar ou outra coisa.");
    }

    @Override
    public void Correr() {
        System.out.println("Cachorros Correm para se divertir ou para atacar.");
    }

    @Override
    public void Comer() {
        System.out.println("Cachorros alimentam-se para ter energia.");
    }

    @Override
    public void Reproduzir() {
        System.out.println("Cachorros Reproduzem para aumentar a espécie.");
    }
    
}