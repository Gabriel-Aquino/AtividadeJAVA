
package animais;

public class Comida {
    private String tipodecomida;

    public String getTipodecomida() {
        return tipodecomida;
    }

    public void setTipodecomida(String tipodecomida) {
        this.tipodecomida = tipodecomida;
    }

    @Override
    public String toString() {
        return "sou essencial para a sobrevivencia das espécies";
    }
    
    
}
