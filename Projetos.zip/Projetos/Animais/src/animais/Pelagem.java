
package animais;

public class Pelagem {
       private String tipodepelagem;

    public String getTipodepelagem() {
        return tipodepelagem;
    }

    public void setTipodepelagem(String tipodepelagem) {
        this.tipodepelagem = tipodepelagem;
    }

    @Override
    public String toString() {
        return "tipo de pelagem = " + this.tipodepelagem;
    }
       
       
}
