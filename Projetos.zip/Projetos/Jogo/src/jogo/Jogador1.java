/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogo;

/**
 *
 * @author aquino
 */
public class Jogador1 {
    private String nome;
    private int pontos = 0;
    private static Jogador1 instance;
    
        private Jogador1(){
            
        }
        public static synchronized Jogador1 getInstance(){
        if (instance == null)
            instance = new Jogador1();
        return instance;
        }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getPontos() {
        return pontos;
    }

    public void setPontos(int pontos) {
        this.pontos = pontos;
    }
    
}
/*@ author aquino
ANTIKIBE DE CODIGO
COPIANÃOCOMÉDIA
*/