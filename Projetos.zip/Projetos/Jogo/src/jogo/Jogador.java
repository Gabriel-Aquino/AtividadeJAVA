package jogo;

public class Jogador {
    private String nome;
    private int pontos;
    private static Jogador instance;
    
        private Jogador(){
            
        }
        public static synchronized Jogador getInstance(){
        if (instance == null)
            instance = new Jogador();
        return instance;
        }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getPontos() {
        return pontos;
    }

    public void setPontos(int pontos) {
        this.pontos = pontos;
    }
        
}
/*@ author aquino
ANTIKIBE DE CODIGO
COPIANÃOCOMÉDIA
*/