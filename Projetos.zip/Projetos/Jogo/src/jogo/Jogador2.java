/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogo;

/**
 *
 * @author aquino
 */
public class Jogador2 {
    private String nome;
    private int pontos = 0;
    private static Jogador2 instance;
    
        private Jogador2(){
            
        }
        public static synchronized Jogador2 getInstance(){
        if (instance == null)
            instance = new Jogador2();
        return instance;
        }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getPontos() {
        return pontos;
    }

    public void setPontos(int pontos) {
        this.pontos = pontos;
    }
    
}
/*@ author aquino
ANTIKIBE DE CODIGO
COPIANÃOCOMÉDIA
*/
