/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jogo;

/**
 *
 * @author aquino
 */
public class Jogo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FUsuario login = new FUsuario();
        login.setVisible(true);
    }
    
}
/*@ author aquino
ANTIKIBE DE CODIGO
COPIANÃOCOMÉDIA
*/
