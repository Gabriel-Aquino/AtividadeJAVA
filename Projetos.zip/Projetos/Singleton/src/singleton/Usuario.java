
package singleton;

import java.util.Date;

public class Usuario {
    private String nome;
    private Date datahora;
    private static Usuario instance;
    
    private Usuario(){
        
}

    public static synchronized Usuario getInstance(){
        if (instance == null)
            instance = new Usuario();
        return instance;
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Date getDatahora() {
        return datahora;
    }

    public void setDatahora(Date datahora) {
        this.datahora = datahora;
    }
    
    
}
