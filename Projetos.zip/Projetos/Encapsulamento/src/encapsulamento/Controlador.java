package encapsulamento;

public interface Controlador {
    public abstract void Ligar();
    public abstract void Desligar();
    public abstract void abrirMenu();
    public abstract void fecharMenu();
    public abstract void MaisVolume();
    public abstract void MenosVolume();
    public abstract void ligarMudo();
    public abstract void desligarMudo();
    public abstract void play();
    public abstract void pause();
}
