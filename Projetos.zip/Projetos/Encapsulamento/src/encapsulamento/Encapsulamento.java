package encapsulamento;

public class Encapsulamento {

    public static void main(String[] args) {
       ControleRemoto c = new ControleRemoto();
       
       c.Ligar();
       c.MaisVolume();
       c.play();
       //c.ligarMudo();
       c.abrirMenu();
       c.fecharMenu();
       
    }
    
}